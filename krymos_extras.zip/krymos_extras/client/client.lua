local function openExtrasMenu()
    local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
    
    if vehicle == 0 then
        lib.notify({ 
            title = Config.Translate.errorTitle, 
            description = Config.Translate.noVehicle, 
            type = 'error' 
        })
        return
    end

    local options = {}

    for i = 1, Config.Settings.MaxExtras do
        if DoesExtraExist(vehicle, i) then
            local isOn = IsVehicleExtraTurnedOn(vehicle, i)
            
            table.insert(options, {
                title = Config.Translate.extraTitle .. i,
                description = isOn and Config.Translate.statusOn or Config.Translate.statusOff,
                icon = isOn and Config.Visuals.iconOn or Config.Visuals.iconOff,
                iconColor = isOn and Config.Visuals.colorOn or Config.Visuals.colorOff,
                onSelect = function()

                    if IsVehicleExtraTurnedOn(vehicle, i) then
                        SetVehicleExtra(vehicle, i, 1) 
                    else
                        SetVehicleExtra(vehicle, i, 0)
                    end
                    
                    openExtrasMenu() 
                end
            })
        end
    end

    if #options == 0 then
        lib.notify({ description = Config.Translate.noExtras, type = 'inform' })
        return
    end

    lib.registerContext({
        id = 'extras_context_menu',
        title = Config.Translate.menuTitle,
        options = options
    })

    lib.showContext('extras_context_menu')
end


Citizen.CreateThread(function()
    while true do
        local sleep = 500 
        
        if IsPedInAnyVehicle(PlayerPedId(), false) then
            sleep = 0
            if IsControlJustPressed(0, Config.MenuControl) then 
                openExtrasMenu()
            end
        end
        
        Citizen.Wait(sleep)
    end
end)