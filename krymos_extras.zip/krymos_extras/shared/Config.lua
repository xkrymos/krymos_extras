Config = {}

Config.MenuControl = 57 

Config.Settings = {
    MaxExtras = 20, 
}

Config.Translate = {
    menuTitle = 'Vehicle Extras Manager',
    noVehicle = 'You must be in a vehicle!',
    noExtras = 'This vehicle has no extras.',
    errorTitle = 'Error',
    extraTitle = 'Extra #',
    statusOn = 'Status: ACTIVE',
    statusOff = 'Status: DISABLED'
}

Config.Visuals = {
    iconOn = 'check',
    colorOn = '#2ecc71',
    iconOff = 'xmark',
    colorOff = '#e74c3c'
}