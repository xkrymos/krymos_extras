fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Krymos'
description 'Vehicle Extras Manager'

shared_scripts {
    '@ox_lib/init.lua',
    'shared/Config.lua' 
}

client_script 'client/client.lua'